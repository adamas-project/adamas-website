# How to use this kit in Obsidian

This kit is a plain folder of Markdown files, so it works in Obsidian, Logseq, VS Code, or any editor. Obsidian is recommended because of backlinks and local-first storage.

## Setup
1. Download and install **Obsidian** (free) from obsidian.md.
2. Click **Open folder as vault** and choose this **"ADAMAS Decision Ledger Starter Kit"** folder.
3. (Optional) In **Settings → Files & Links**, set the default template folder to **Templates/**.

## The workflow
- For each real decision, duplicate **Templates/Decision Template.md** into **Decisions/**.
- Name files like: `YYYY-MM-DD - <short decision>.md` so they sort chronologically.
- Use the **domain** field (Hiring/Sales/Product/Finance/Ops) so you can filter later.
- Use `[[double brackets]]` in the **Linked** section to connect related decisions — this is how reasoning compounds over time.

## Why local-first
Your decisions are your most sensitive IP. Keeping the vault on your own machine means nothing leaves your company. ADAMAS extends exactly this principle — a local-first vault, with an AI agent doing the capture, linking, and asset generation for you.

## From kit to system
This kit is the *what*. ADAMAS is the *done-for-you*:
- We interview you and load your existing decisions into the ledger.
- An AI agent captures new decisions and links them automatically.
- The same ledger generates onboarding docs, hiring frameworks, and investor materials on demand.

Learn more at **adamas-project.com**.
