---
date: 2026-05-20
decision: "Run our knowledge system on a local Mac Mini instead of the cloud"
owner: "Founder"
domain: "Ops"
status: "Decided"
review: 2026-11-20
---

# Move to local-first hosting

## Context
Our cloud AI bill had grown to ~$380/month and kept climbing, and our most sensitive IP (client and product decisions) was sitting on third-party servers. Several clients in engineering specifically asked where their data lives.

## Options considered
- **Option A** — Stay fully cloud; simplest, but rising cost and data-residency concerns.
- **Option B** — Local-first on a Mac Mini M4, cloud only for hard tasks (hybrid).
- **Option C** — Fully local, no cloud at all; cheapest but slower on heavy tasks.

## Decision
Adopt the hybrid model (Option B): a Mac Mini M4 runs the vault and agent 24/7; cloud is used only for occasional heavy tasks.

## Why (the reasoning)
~80% of our daily workflows don't need a frontier model. Local hardware costs ~$2–3/month in electricity versus ~$380 in cloud fees, and keeping IP on-premise is a selling point, not a compromise. Hybrid keeps a cloud escape hatch for the rare hard task.

## Linked
- [[2026-06-01 - Example - First sales hire]]

## Outcome / review notes
_(Review in November: confirm actual cost savings and any latency complaints.)_
