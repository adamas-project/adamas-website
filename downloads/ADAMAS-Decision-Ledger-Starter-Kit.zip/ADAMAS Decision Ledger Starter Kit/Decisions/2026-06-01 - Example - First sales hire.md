---
date: 2026-06-01
decision: "Hire a part-time SDR before a full-time AE"
owner: "Founder"
domain: "Sales"
status: "Decided"
review: 2026-09-01
---

# First sales hire

## Context
The founder was the only person doing outbound and could no longer keep up with both delivery and pipeline. Budget was tight and we were unsure which sales motion would convert best.

## Options considered
- **Option A** — Full-time AE immediately; faster ramp, higher risk/cost.
- **Option B** — Part-time SDR to book qualified calls the founder closes.
- **Option C** — Outsource to an agency; fast but less control and learning.

## Decision
Hire a part-time SDR (Option B) to handle top-of-funnel; founder keeps closing for now.

## Why (the reasoning)
We don't yet have a documented, repeatable close, so handing closing to a new AE would risk our best asset before it's systematised. An SDR lets us scale the top of the funnel cheaply while we capture the closing playbook in the ledger — then a future AE can onboard from it.

## Linked
- [[2026-05-20 - Example - Move to local-first hosting]]

## Outcome / review notes
_(Review in September: did the SDR free founder time, and is the closing playbook captured?)_
