# ADAMAS — Decision Ledger Starter Kit

Welcome. This is a free, manual starter version of the system behind **ADAMAS by Falcon Intelligence Group** — a *decision ledger* that captures **why** your company made its decisions, not just what it did.

Most tools store information. None capture the reasoning behind a decision — so when people leave, onboard, or an investor asks "why did you choose X?", the answer is gone. This kit fixes the smallest version of that, today, for free.

## What's inside
- **Templates/Decision Template.md** — the structured record for one decision.
- **Decisions/** — two worked examples to copy.
- **README.md** — how to run this in Obsidian (5 minutes).

## The schema (the whole idea)
Every material decision is captured with five things:

| Field | Question it answers |
|---|---|
| **Context** | What was the situation, constraint, or pressure at the time? |
| **Decision** | What exactly did we decide? |
| **Owner** | Who made the call? |
| **Reasoning (Why)** | The thinking behind it — the part normally lost. |
| **Domain** | Hiring · Sales · Product · Finance · Ops |
| **Linked** | Which other decisions does this connect to? |

## How to start (2 minutes)
1. Open **Decisions/** and copy the **Decision Template** for your most recent important decision.
2. Fill in Context → Decision → Why. Don't overthink it; a few honest lines beat a polished doc.
3. Do one per week. In 90 days you'll have a living record of how your company actually thinks.

When the manual habit starts paying off — and you want it captured automatically, structured, linked, and turned into onboarding/investor/hiring assets — that's what ADAMAS does for you.

→ **adamas-project.com**  ·  Book a Clarity Audit: m@adamas-project.com
