---
date: YYYY-MM-DD
decision: "<one line: what was decided>"
owner: "<who made the call>"
domain: "<Hiring | Sales | Product | Finance | Ops>"
status: "<Decided | Revisit | Superseded>"
review: YYYY-MM-DD
---

# <Decision title>

## Context
What was the situation at the time? What constraints, data, deadlines, or pressure shaped this? (Write for a future colleague who wasn't in the room.)

## Options considered
- **Option A** —
- **Option B** —
- **Option C** —

## Decision
What exactly did we decide?

## Why (the reasoning)
The thinking behind the choice. This is the field that is normally lost — be specific. What did we believe? What were we trading off? What would change our mind?

## Linked
- [[ ]]

## Outcome / review notes
_(Fill in later.)_ What actually happened? Was the reasoning sound?
